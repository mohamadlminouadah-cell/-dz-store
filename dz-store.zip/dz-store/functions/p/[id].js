// معاينة مشاركة المنتج (فيسبوك/واتساب/ماسنجر...): تعرض اسم المنتج وصورته وسعره ثم تحوّل الزائر للمتجر
import cfg from '../../web/config.json';

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = (n) => `${Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ')} دج`;

export async function onRequest({ params, request }) {
  const origin = new URL(request.url).origin;
  const id = String(params.id || '');
  if (!/^[0-9a-f-]{36}$/i.test(id)) return Response.redirect(origin + '/', 302);
  try {
    const h = { apikey: cfg.supabaseAnonKey, Authorization: `Bearer ${cfg.supabaseAnonKey}` };
    const [pr, st] = await Promise.all([
      fetch(`${cfg.supabaseUrl}/rest/v1/products?id=eq.${id}&status=neq.hidden&select=name,description,price,old_price,images`, { headers: h }).then((r) => r.json()),
      fetch(`${cfg.supabaseUrl}/rest/v1/settings?id=eq.1&select=store_name`, { headers: h }).then((r) => r.json()),
    ]);
    const p = Array.isArray(pr) && pr[0];
    if (!p) return Response.redirect(origin + '/', 302);
    const site = (Array.isArray(st) && st[0]?.store_name) || 'المتجر';
    const title = `${p.name} — ${fmt(p.price)}`;
    const desc = (p.description || `اطلب الآن من ${site} والدفع عند الاستلام.`).replace(/\s+/g, ' ').slice(0, 180);
    const img = p.images?.[0] || '';
    const target = `${origin}/?p=${id}`;
    const html = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<title>${esc(title)}</title><meta name="description" content="${esc(desc)}">
<meta property="og:type" content="product"><meta property="og:site_name" content="${esc(site)}">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}">
<meta property="og:url" content="${esc(`${origin}/p/${id}`)}">${img ? `<meta property="og:image" content="${esc(img)}">` : ''}
<meta property="product:price:amount" content="${p.price}"><meta property="product:price:currency" content="DZD">
<meta name="twitter:card" content="${img ? 'summary_large_image' : 'summary'}">
<meta http-equiv="refresh" content="0;url=${esc(target)}"></head>
<body><p><a href="${esc(target)}">${esc(title)}</a></p><script>location.replace(${JSON.stringify(target)})</script></body></html>`;
    return new Response(html, { headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'public, max-age=300' } });
  } catch {
    return Response.redirect(origin + '/', 302);
  }
}
